module ru.shafigullina.shafigullina {
    requires javafx.controls;
    requires javafx.fxml;


    opens ru.shafigullina.shafigullina to javafx.fxml;
    exports ru.shafigullina.shafigullina;
    exports ru.shafigullina.shafigullina.controller;
    opens ru.shafigullina.shafigullina.controller to javafx.fxml;
}